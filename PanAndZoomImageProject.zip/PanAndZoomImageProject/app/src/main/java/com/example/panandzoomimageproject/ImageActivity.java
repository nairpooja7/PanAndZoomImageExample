package com.example.panandzoomimageproject;

import android.graphics.Matrix;
import android.graphics.PointF;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;


public class ImageActivity extends AppCompatActivity {

    ImageView pan_zoom;

    Matrix matrix = new Matrix();
    Matrix savedMatrix = new Matrix();
    PointF startPoint = new PointF();
    PointF midPoint = new PointF();
    float oldDist = 1f;
    static final int NONE = 0;
    static final int DRAG = 1;
    static final int ZOOM = 2;
    int mode = NONE;


    private float dx; // postTranslate X distance
    private float dy; // postTranslate Y distance
    private float[] matrixValues = new float[9];
    float matrixX = 0; // X coordinate of matrix inside the ImageView
    float matrixY = 0; // Y coordinate of matrix inside the ImageView
    float width = 0; // width of drawable
    float height = 0; // height of drawable



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
        DisplayMetrics metrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metrics);
        int width = metrics.widthPixels;
        //int height= metrics.heightPixels;
        pan_zoom = (ImageView)findViewById(R.id.img_zoom);

        Picasso.with(this)
                .load(R.drawable.image1)
                //.fit()
                //.centerCrop()
                .resize(width, 0)
                //.centerInside()
                .into(pan_zoom);


        //Picasso.with(getApplicationContext()).load(R.drawable.image1).centerCrop().into(pan_zoom);



        /*Bitmap bitmapImageLocal = BitmapFactory.decodeResource(
                getApplicationContext().getResources(),
                R.drawable.image1);
                int nh = (int) ( bitmapImageLocal.getHeight() * (512.0 / bitmapImageLocal.getWidth()) );
Bitmap scaled = Bitmap.createScaledBitmap(bitmapImageLocal, 512, nh, true);

        pan_zoom.setImageBitmap(scaled);*/


        pan_zoom.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {

                ImageView view = (ImageView) v;

                System.out.println("matrix=" + savedMatrix.toString());
                switch (event.getAction() & MotionEvent.ACTION_MASK) {
                    case MotionEvent.ACTION_DOWN:

                        savedMatrix.set(matrix);
                        startPoint.set(event.getX(), event.getY());
                        mode = DRAG;
                        break;

                    case MotionEvent.ACTION_POINTER_DOWN:

                        oldDist = spacing(event);

                        if (oldDist > 10f) {
                            savedMatrix.set(matrix);
                            midPoint(midPoint, event);
                            mode = ZOOM;
                        }
                        break;

                    case MotionEvent.ACTION_UP:

                    case MotionEvent.ACTION_POINTER_UP:

                        mode = NONE;

                        break;

                    case MotionEvent.ACTION_MOVE:
                        if (mode == DRAG) {


                           matrix.set(savedMatrix);
                            matrix.postTranslate(event.getX() - startPoint.x, event.getY() - startPoint.y);


                            /*matrix.set(savedMatrix);

                            matrix.getValues(matrixValues);
                            matrixX = matrixValues[2];
                            matrixY = matrixValues[5];
                            width = matrixValues[0] * (((ImageView) view).getDrawable()
                                    .getIntrinsicWidth());
                            height = matrixValues[4] * (((ImageView) view).getDrawable()
                                    .getIntrinsicHeight());

                            dx = event.getX() - startPoint.x;
                            dy = event.getY() - startPoint.y;

                            //if image will go outside left bound
                            if (matrixX + dx < 0){
                                dx = -matrixX;
                            }
                            //if image will go outside right bound
                            if(matrixX + dx + width > view.getWidth()){
                                dx = view.getWidth() - matrixX - width;
                            }
                            //if image will go oustside top bound
                            if (matrixY + dy < 0){
                                dy = -matrixY;
                            }
                            //if image will go outside bottom bound
                            if(matrixY + dy + height > view.getHeight()){
                                dy = view.getHeight() - matrixY - height;
                            }
                            matrix.postTranslate(dx, dy);*/
                        } else if (mode == ZOOM) {
                           float newDist = spacing(event);
                            if (newDist > 10f) {
                                matrix.set(savedMatrix);
                                float scale = newDist / oldDist;
                                matrix.postScale(scale, scale, midPoint.x, midPoint.y);
                            }
                        }
                        break;

                }
                view.setImageMatrix(matrix);

                return true;
            }

            private float spacing(MotionEvent event) {
                float x = event.getX(0) - event.getX(1);
                float y = event.getY(0) - event.getY(1);
                return (float) Math.sqrt(x * x + y * y);
            }

            private void midPoint(PointF point, MotionEvent event) {
                float x = event.getX(0) + event.getX(1);
                float y = event.getY(0) + event.getY(1);
                point.set(x / 2, y / 2);
            }
        });

    }





    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }




}


